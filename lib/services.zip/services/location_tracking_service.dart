import 'dart:async';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:flutter/foundation.dart';
import 'driver_service.dart';
import '../utils/constants.dart';

/// Service for tracking driver location in the background during active trips
class LocationTrackingService {
  static final LocationTrackingService _instance = LocationTrackingService._internal();
  factory LocationTrackingService() => _instance;
  LocationTrackingService._internal();

  final DriverService _driverService = DriverService();
  Timer? _locationUpdateTimer;
  bool _isTracking = false;
  int? _currentDriverId;
  int? _currentTripId;
  
  /// Callback to notify when location tracking status changes
  Function(bool)? onTrackingStatusChanged;
  
  /// Callback to notify when location update fails
  Function(String)? onError;

  /// Check if location services are enabled
  Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// Request location permission
  Future<LocationPermission> requestLocationPermission() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      debugPrint('⚠️ Location services are disabled');
      return LocationPermission.denied;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        debugPrint('⚠️ Location permissions are denied');
        return LocationPermission.denied;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      debugPrint('⚠️ Location permissions are permanently denied');
      return LocationPermission.deniedForever;
    }

    debugPrint('✅ Location permission granted');
    return permission;
  }

  /// Get current location
  Future<Position?> getCurrentLocation() async {
    try {
      LocationPermission permission = await requestLocationPermission();
      
      if (permission != LocationPermission.whileInUse && 
          permission != LocationPermission.always) {
        debugPrint('❌ Location permission not granted');
        onError?.call('Location permission not granted');
        return null;
      }

      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
        timeLimit: const Duration(seconds: 10),
      );

      debugPrint('📍 Current location: ${position.latitude}, ${position.longitude}');
      return position;
    } catch (e) {
      debugPrint('❌ Error getting current location: $e');
      onError?.call('Failed to get current location: ${e.toString()}');
      return null;
    }
  }

  /// Get address from coordinates (optional, can be implemented with geocoding)
  Future<String?> getAddressFromCoordinates(double latitude, double longitude) async {
    try {
      // Using placemark for address
      List<Placemark> placemarks = await placemarkFromCoordinates(latitude, longitude);
      if (placemarks.isNotEmpty) {
        Placemark place = placemarks[0];
        String address = [
          place.street,
          place.subLocality,
          place.locality,
          place.administrativeArea,
          place.country,
        ].where((element) => element != null && element.isNotEmpty).join(', ');
        return address.isNotEmpty ? address : null;
      }
      return null;
    } catch (e) {
      debugPrint('⚠️ Error getting address: $e');
      return null;
    }
  }

  /// Start location tracking for an active trip
  /// Updates location every [updateInterval] seconds (default: 15 seconds)
  Future<bool> startLocationTracking({
    required int driverId,
    required int tripId,
    Duration updateInterval = const Duration(seconds: 15),
  }) async {
    if (_isTracking) {
      debugPrint('⚠️ Location tracking is already active');
      return false;
    }

    // Request permission first
    LocationPermission permission = await requestLocationPermission();
    if (permission != LocationPermission.whileInUse && 
        permission != LocationPermission.always) {
      debugPrint('❌ Cannot start tracking: Location permission not granted');
      onError?.call('Location permission not granted. Please enable location permissions.');
      return false;
    }

    // Check if location services are enabled
    bool serviceEnabled = await isLocationServiceEnabled();
    if (!serviceEnabled) {
      debugPrint('❌ Cannot start tracking: Location services are disabled');
      onError?.call('Location services are disabled. Please enable location services.');
      return false;
    }

    _currentDriverId = driverId;
    _currentTripId = tripId;
    _isTracking = true;
    onTrackingStatusChanged?.call(true);

    debugPrint('🚀 Starting location tracking for driver $driverId, trip $tripId');
    debugPrint('⏱️ Update interval: ${updateInterval.inSeconds} seconds');

    // Send initial location update immediately
    await _sendLocationUpdate();

    // Set up periodic location updates
    _locationUpdateTimer = Timer.periodic(updateInterval, (timer) async {
      if (!_isTracking) {
        timer.cancel();
        return;
      }

      await _sendLocationUpdate();
    });

    return true;
  }

  /// Send location update to backend
  Future<void> _sendLocationUpdate() async {
    if (!_isTracking || _currentDriverId == null || _currentTripId == null) {
      return;
    }

    try {
      // Get current location
      Position? position = await getCurrentLocation();
      if (position == null) {
        debugPrint('⚠️ Failed to get position, skipping location update');
        return;
      }

      // Get address (optional, can be null)
      String? address = await getAddressFromCoordinates(
        position.latitude,
        position.longitude,
      );

      // Call saveLocationUpdate API
      final response = await _driverService.saveLocationUpdate(
        _currentDriverId!,
        _currentTripId!,
        position.latitude,
        position.longitude,
        address,
      );

      if (response[AppConstants.keySuccess] == true) {
        debugPrint('✅ Location update sent successfully: ${position.latitude}, ${position.longitude}');
      } else {
        String errorMessage = response[AppConstants.keyMessage] ?? 'Unknown error';
        debugPrint('❌ Location update failed: $errorMessage');
        onError?.call(errorMessage);
        
        // If trip is not in progress, stop tracking
        if (errorMessage.contains('not in progress') || 
            errorMessage.contains('IN_PROGRESS')) {
          debugPrint('🛑 Stopping location tracking: Trip is not in progress');
          stopLocationTracking();
        }
      }
    } catch (e) {
      debugPrint('❌ Error sending location update: $e');
      onError?.call('Failed to send location update: ${e.toString()}');
    }
  }

  /// Stop location tracking
  void stopLocationTracking() {
    if (!_isTracking) {
      return;
    }

    debugPrint('🛑 Stopping location tracking');
    
    _locationUpdateTimer?.cancel();
    _locationUpdateTimer = null;
    _isTracking = false;
    _currentDriverId = null;
    _currentTripId = null;
    
    onTrackingStatusChanged?.call(false);
  }

  /// Check if location tracking is currently active
  bool get isTracking => _isTracking;

  /// Get current driver ID being tracked
  int? get currentDriverId => _currentDriverId;

  /// Get current trip ID being tracked
  int? get currentTripId => _currentTripId;

  /// Dispose resources
  void dispose() {
    stopLocationTracking();
  }
}

